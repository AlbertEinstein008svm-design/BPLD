README.txt

## Purpose
This script applies Benford’s Law–based statistical tests to analyze datasets of first-digit frequencies. It implements the **Bi-Polar Log Deviation (BPLD)** method developed by the author, along with established goodness-of-fit tests: **Mean Absolute Deviation (MAD)**, **Sum of Squared Deviations (SSD)**, and Monte Carlo–based p-value estimation for robustness.

The purpose is to detect anomalies and possible manipulations in numerical datasets, with application here to Chinese banks’ Non-Performing Loan (NPL) data across multiple years.

---

## Input Format
- Each dataset must be provided as an **Excel file (.xlsx)**.
- The file must contain two columns:
  - `FirstDigit`: integers 1–9 (the first significant digit).
  - `Freq.`: the observed frequency count for each digit.

Example structure:
```
FirstDigit   Freq.
1            35
2            21
3            18
...
9             5
```

---

## How to Use
1. Place all Excel files (e.g., `China 2010.xlsx`, `China 2011.xlsx`, …) in the working directory.
2. Open the script in Google Colab or any Python environment with the required libraries installed:
   - pandas
   - numpy
   - matplotlib
   - scipy
3. Update the file path in the following line to point to the dataset you want to analyze:
   ```python
   one_deals_df = pd.read_excel('/content/China 2013.xlsx').sort_values(by="FirstDigit")
   ```
4. Run the script. It will automatically:
   - Compute **BPLD**, **MAD**, and **SSD**.
   - Perform a **Monte Carlo p-value test** for BPLD.
   - Generate diagnostic plots (ln–ln foci plot and simulated null histograms).
   - Print verdicts on conformity/nonconformity.

---

## Output
For each dataset, the script outputs:
- **BPLD value** and Monte Carlo p-value.
- **MAD score** and conformity verdict (acceptable / marginal conformity / nonconformity).
- **SSD score** and conformity verdict.
- Diagnostic plots:
  - Log–log comparison with Benford distribution.
  - Null simulation histogram with observed deviation.
- List of digits exceeding the ±4 percentage point gate.

---

## Applicability to Multiple Datasets
The same code applies to every dataset in the folder.
- To analyze another year, simply change the filename in the `pd.read_excel()` line.
- For batch analysis of multiple files, the script can be looped over a list of filenames.

---

## Notes
- The code uses **Jeffreys smoothing (Dirichlet-½ prior)** to handle zero frequencies safely.
- One can reproduce results year by year by replacing the file name.
