# BPLD Sensitivity Analysis

This repository contains Python code for conducting sensitivity analysis of the Bipolar Logarithmic Deviation (BPLD) method for testing conformity to Benford’s Law.

The code evaluates how different tolerance values (`τ`) affect the Type-I error rate, statistical power, and empirical classification of benchmark datasets.

## File

- `BPLD_Sensitivity.ipynb`: Main Jupyter Notebook containing the full simulation and plotting code.

## Purpose

The notebook is designed to support the appendix/supplementary analysis of the paper:

**Bipolar Logarithmic Method for Benford’s Law Deviation Detection**

The analysis examines whether the tolerance parameter used in the Monte Carlo inference stage produces a reasonable balance between avoiding false positives and maintaining power against structured deviations.

## Main Features

The code performs three major analyses:

1. **Type-I Error Analysis**
   - Simulates datasets under the Benford null distribution.
   - Estimates rejection rates for different tolerance values.
  

2. **Power Analysis**
   - Tests BPLD under three structured alternatives:
     - Rare-digit inflation
     - Benford–uniform mixture
     - Smooth logarithmic tilt
   
3. **Population Dataset Sensitivity**
   - Applies BPLD to Benford’s original population dataset.
   - Compares Monte Carlo null distributions under `τ = 0.02` and `τ = 0.04`.
  

## Requirements

The notebook requires the following Python packages:

```python
numpy
matplotlib