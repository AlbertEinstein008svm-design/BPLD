README.txt

AIM
-------
This repository contains Python code to evaluate the conformity of various datasets to Benford’s Law. 
The main method implemented is the Bi-Polar Log Deviation (BPLD), which we introduce and benchmark 
against traditional methods:
- Chi-square goodness-of-fit test
- Kolmogorov–Smirnov (KS) test (discrete counts-based, with Monte Carlo p-value)
- Mean Absolute Deviation (MAD)
- Sum of Squared Deviations (SSD)

The same script can be applied to any dataset of digit frequencies provided in Excel format.

Input Data
----------
Each Excel file should contain two columns:
- FirstDigit: integers from 1 to 9
- Freq.: the observed frequency (count) of each first digit

Example:

FirstDigit | Freq.
-----------|-------
1          | 322
2          | 180
3          | 140
...        | ...
9          | 58



How to Run
----------
1. Place all Excel files (datasets) in the working directory.
2. Update the 'files = [ ... ]' 
3. Run the script in Python 3 (tested in Google Colab / Jupyter).

The script will:
- Process each dataset in turn.
- Apply BPLD, Chi-square, KS, MAD, and SSD tests.


Output
------
- Console log: Prints detailed results (BPLD statistic, Chi-square test, KS test, MAD & SSD values).
- BPLD visual conformity (or non-conformity) with Benford's law

Notes
-----
- The code is generalizable: the same function is applied to every dataset in the folder.
- Monte Carlo simulations (B=10000) ensure robust p-values for BPLD and KS tests.
- MAD verdict thresholds follow Nigrini-inspired cutoffs.
