Suspicious Twitter Accounts – Benford Analysis
==============================================

This package analyzes 83 suspicious Twitter accounts using Benford’s Law–based statistical tests. 
It produces per-variable results (Friend, Follower, Status counts), summary flags, and multiple plots.

------------------------------------------------
Requirements
------------------------------------------------
- Python 3.8+
- Install dependencies:
    pip install numpy pandas scipy matplotlib xlsxwriter

------------------------------------------------
Input
------------------------------------------------
- suspicious83.zip 
  Contains 83 suspicious accounts (one file per account).
  Each file is tab-separated with at least:
    Account_ID, Friend_Count, Follower_Count, Status_Count

------------------------------------------------
Usage
------------------------------------------------
Run the analysis with:

    Analysis_of_Twitter_accounts.py --zip-in suspicious83.zip

Progress updates will print to the terminal every ~25 accounts.

------------------------------------------------
Outputs (saved in ./outputs/)
------------------------------------------------
- suspicious83_results.xlsx  → per-variable results for each account
- summary_flags.xlsx         → aggregated flag summary
- Plots:
    * failure_rates_barplot.png
    * Friend_Count_failures_pie.png
    * Follower_Count_failures_pie.png
    * Status_Count_failures_pie.png
    * Combined_failures_pie.png
    * failures_heatmap.png

------------------------------------------------
Test Criteria
------------------------------------------------
- BPLD: Monte Carlo p < 0.05
- MAD:  > 0.015
- SSD:  ≥ 0.01 (Non-Benford)
- Chi-square & KS: p < 0.05

------------------------------------------------
Note
------------------------------------------------
Place suspicious83.zip and Analysis_of_Twitter_accounts.py 
in the same folder and run the command above to reproduce all tables and figures.
